package com.kh.pdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdataApplication.class, args);
	}

}
