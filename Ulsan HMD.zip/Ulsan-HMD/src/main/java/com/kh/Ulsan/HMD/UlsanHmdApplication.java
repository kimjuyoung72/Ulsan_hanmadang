package com.kh.Ulsan.HMD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UlsanHmdApplication {

	public static void main(String[] args) {
		SpringApplication.run(UlsanHmdApplication.class, args);
	}

}
