package com.kh.Ulsan.HMD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UlsanHmdApplicationTests {

	@Test
	void contextLoads() {
	}

}
