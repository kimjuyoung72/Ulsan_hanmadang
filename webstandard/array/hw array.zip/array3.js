const data = {
    result:'success', //success: 수신성공, fail:수신실패
    data:[
        {name:'이름1', gender:'남', age:10, blood:'A'},
        {name:'이름2', gender:'여', age:20, blood:'B'},
        {name:'이름3', gender:'남', age:30, blood:'AB'},
        {name:'이름4', gender:'여', age:40, blood:'O'},
        {name:'이름5', gender:'남', age:50, blood:'A'}
    ]
}
//0. 회원수
if(data.result == 'success'){
    console.log(data.data.length);
}
//1. 회원이름 출력
if(data.result == 'success'){
    data.data.forEach(ele => console.log(ele.name));
    
}
//2. 나이의 총합
// {
// let sumAge = 0;
// if(data.result == 'success'){
//     data.data.forEach(ele => sumAge += ele.age);
//     console.log(`회원나이총합: ${sumAge}`);
// }
// }    
{
    // const result = data.data.reduce( function(acc, ele){
    //     return acc + ele.age;
    // },0);
    const result = data.data.reduce( (acc,ele) => acc + parseInt(ele.age), 0);
    // const result = reduce((acc,ele,data.data) => acc + parseInt(ele.age ), 0);
    console.log(`회원나이총합: ${result}`);
}
//3. 남자회원의 수
if(data.result == 'success'){
    console.log(data.data.filter(ele => ele.gender == '남').length);
}
//4. 남자회원, 여자회원을 분리하여 배열에 저장
if(data.result == 'success'){
    const males = [];
    const females = [];
    data.data.filter(ele => ele.gender == '남').forEach(ele => males.push(ele));
    data.data.filter(ele => ele.gender == '여').forEach(ele => females.push(ele));
    console.log(males);
    console.log(females);

}
//5. 남자회원 나이의 총합 출력
if(data.result == 'success'){
    let sumAge = 0;
    data.data.filter(ele => ele.gender == '남').forEach(ele => sumAge += ele.age);
    console.log(sumAge);
}
//6. A형 회원 나이 총합 출력
if(data.result == 'success'){
    let sumAge = 0;
    data.data.filter(ele => ele.blood == 'A').forEach(ele => sumAge += ele.age);
    console.log(sumAge);
}
//7. 이름이 '이름3'인 회원의 혈액형?
if(data.result == 'success'){
    data.data.filter(ele => ele.name == '이름3').forEach(ele => console.log(ele.blood));
}
