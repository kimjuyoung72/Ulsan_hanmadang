package com.kh.hanmadang.web.session;

public class LoginOkConst {
  public static final String LOGIN_MEMBER = "LoginMember";
}
