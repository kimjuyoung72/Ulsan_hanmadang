package com.kh.kopis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KopisApplication {

	public static void main(String[] args) {
		SpringApplication.run(KopisApplication.class, args);
	}

}
