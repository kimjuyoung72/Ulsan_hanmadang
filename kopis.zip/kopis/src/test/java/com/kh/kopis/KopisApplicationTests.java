package com.kh.kopis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KopisApplicationTests {

	@Test
	void contextLoads() {
	}

}
